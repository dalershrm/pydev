from django.shortcuts import render

# Create your views here.

def index(request):
    return render(request,'mainpage/homepage.html')


def contact(request):
    return render(request,'mainpage/basic.html',
    {'values':['Саволхои худро ба ин сурогаи электронии зерин равон кунед.','bjsoft98@gmail.com']})

def info_(request):
    return render(request,'mainpage/info.html',
    {'values':['Саволхои худро ба ин сурогаи электронии зерин равон кунед.','bjsoft98@gmail.com']})
