from django.apps import AppConfig


class HtmlpostConfig(AppConfig):
    name = 'htmlpost'
