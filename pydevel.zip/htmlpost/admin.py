from django.contrib import admin
from htmlpost.models import HtmlArticles

# Register your models here.

admin.site.register(HtmlArticles)