from django.contrib import admin
from phppost.models import PhpArticles

# Register your models here.

admin.site.register(PhpArticles)