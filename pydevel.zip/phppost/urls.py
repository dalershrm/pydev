from django.conf.urls import url, include
from django.views.generic import ListView, DetailView
from phppost.models import PhpArticles



urlpatterns = [
    url(r'^$', 
    ListView.as_view(queryset=PhpArticles.objects.all().order_by("date_public")[:20],
    template_name = "phppost/posts.html")),
    url(r'^(?P<pk>\d+)$', DetailView.as_view(model = PhpArticles, 
    template_name = "phppost/post.html"))
]