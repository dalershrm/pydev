from django.apps import AppConfig


class PhppostConfig(AppConfig):
    name = 'phppost'
