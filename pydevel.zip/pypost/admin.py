from django.contrib import admin
from pypost.models import Articles

# Register your models here.

admin.site.register(Articles)
