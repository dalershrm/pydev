from django.apps import AppConfig


class PypostConfig(AppConfig):
    name = 'pypost'
